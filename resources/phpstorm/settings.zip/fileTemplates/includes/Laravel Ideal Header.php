<?php
#parse("PHP File Header.php")
#if ($CLASS_NAMESPACE)

namespace $CLASS_NAMESPACE;
#else

namespace Plop;
#end
#if ($USAGES)

$USAGES
#end