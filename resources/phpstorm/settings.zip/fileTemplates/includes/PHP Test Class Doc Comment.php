/**
 * @coversDefaultClass #[[$testedClass$]]#
 */