<?php
#if (${NAMESPACE})

namespace ${NAMESPACE};

#end
use Tests\TestCase;
use Illuminate\Foundation\Testing\DatabaseTransactions;

#parse("PHP Test Class Doc Comment.php")
class ${NAME} extends TestCase
{
    use DatabaseTransactions;
    
    /** 
     * @test
     * @covers ::#[[$covers$]]#
     */
    public function #[[$simpleTest$]]#()
    {
        #[[$END$]]#
    }
}
