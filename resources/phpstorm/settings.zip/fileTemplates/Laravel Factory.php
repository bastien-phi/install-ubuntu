<?php

use Faker\Generator as Faker;

/** @var \Illuminate\Database\Eloquent\Factory ${DS}factory */

${DS}factory->define(#[[$Model$]]#::class, function (Faker ${DS}faker) {
    return [
        #[[$END$]]#
    ];
});
