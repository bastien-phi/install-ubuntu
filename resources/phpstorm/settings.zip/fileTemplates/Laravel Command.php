<?php

#if (${NAMESPACE})

namespace ${NAMESPACE};

#end
use Illuminate\Console\Command;
class ${NAME} extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected ${DS}signature = '#[[$command$]]#:#[[$name$]]#';

    /**
     * The console command description.
     *
     * @var string
     */
    protected ${DS}description = '#[[$description$]]#';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        #[[$END$]]#
    }
}
