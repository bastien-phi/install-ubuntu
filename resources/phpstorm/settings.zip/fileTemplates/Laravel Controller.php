<?php
#if (${NAMESPACE})

namespace ${NAMESPACE};

#end
use Soyhuce\Api\Http\ApiController;

class ${NAME} extends ApiController
{

    public function #[[$method$]]#()
    {
        #[[$END$]]#
    }
}