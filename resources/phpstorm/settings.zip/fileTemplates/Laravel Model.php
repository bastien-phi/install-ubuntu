<?php
#if (${NAMESPACE})

namespace ${NAMESPACE};

#end
use Soyhuce\Api\Models\Model;

class ${NAME}  extends Model
{
    /**
     * @var bool
     */
    public ${DS}timestamps = #[[$true$]]#;

    /**
     * @var array
     */
    protected ${DS}fillable = [
        #[[$END$]]#
    ];
}
