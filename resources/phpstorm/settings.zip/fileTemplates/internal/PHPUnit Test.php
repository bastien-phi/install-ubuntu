<?php
#if (${NAMESPACE})

namespace ${NAMESPACE};

#end

use Illuminate\Foundation\Testing\DatabaseTransactions;
use Tests\TestCase;

class ${NAME} extends TestCase
{
  use DatabaseTransactions;
  
}