<?php
#if (${NAMESPACE})

namespace ${NAMESPACE};

#end
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class ${NAME}  extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct()
    {
        // ${DS}this->queue = '';
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  ${DS}notifiable
     * @return array
     */
    public function via(${DS}notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  ${DS}notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail(${DS}notifiable)
    {
        return (new MailMessage)
                    ->line('The introduction to the notification.')
                    ->action('Notification Action', url('/'))
                    ->line('Thank you for using our application!');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  ${DS}notifiable
     * @return array
     */
    public function toArray(${DS}notifiable)
    {
        return [
            //
        ];
    }
}
