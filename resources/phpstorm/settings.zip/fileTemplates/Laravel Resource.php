<?php
#if (${NAMESPACE})

namespace ${NAMESPACE};

#end
use Illuminate\Http\Resources\Json\JsonResource;

/** 
 * @mixin #[[$END$]]#
 */
class ${NAME} extends JsonResource
{
    public function toArray(${DS}request)
    {
        return [
        ];
    }
}
