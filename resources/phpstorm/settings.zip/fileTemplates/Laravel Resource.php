<?php
#if (${NAMESPACE})

namespace ${NAMESPACE};

#end
use Illuminate\Http\Resources\Json\JsonResource;

class ${NAME} extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  ${DS}request
     * @return array
     */
    public function toArray(${DS}request)
    {
        return [
        ];
    }
    
    /**
     * @SWG\Definition(
     *     definition="#[[$definition$]]#",
     *     required={"#[[$END$]]#"},
     *     @SWG\Property(property="", type="", example="", description=""),
     *)
     */
}
