#parse("Laravel Ideal Header.php")
#if ($REFRESH_DATABASE)
use Illuminate\Foundation\Testing\DatabaseTransactions;

#parse("Laravel Ideal Class Name.php")
{
    use DatabaseTransactions;

#else

        #parse("Laravel Ideal Class Name.php")
{
#end
    /**
     * @test
     */
    public function testBasic(): void
    {
        
    }
}