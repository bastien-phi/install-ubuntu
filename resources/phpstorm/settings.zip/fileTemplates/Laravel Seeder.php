<?php

use Illuminate\Database\Seeder;

class ${NAME} extends Seeder
{
    public function run()
    {
        #[[$END$]]#
    }
}
