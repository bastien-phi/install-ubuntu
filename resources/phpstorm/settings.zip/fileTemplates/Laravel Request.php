<?php
#if (${NAMESPACE})

namespace ${NAMESPACE};

#end
use App\Http\Requests\Request;

class ${NAME} extends Request
{

    protected ${DS}rules = [
        #[[$END$]]#
    ];

}
