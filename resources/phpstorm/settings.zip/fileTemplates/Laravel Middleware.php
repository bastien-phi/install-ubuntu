<?php
#if (${NAMESPACE})

namespace ${NAMESPACE};

#end
use Closure;

class ${NAME} 
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  ${DS}request
     * @param  \Closure  ${DS}next
     * @return mixed
     */
    public function handle(${DS}request, Closure ${DS}next)
    {
        #[[$END$]]#
        return ${DS}next(${DS}request);
    }
}
